/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package helpers;

/**
 *
 * @author Usuario
 */
public class Deportista extends Persona{

    public Deportista() {
    setEdad("19");
    setNombre("Victor");
    setApellido("Hernandez)";
    setGenero("Masculino");
    }
   
}
